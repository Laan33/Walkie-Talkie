<script>
     import NavBar from '../components/Navigation.vue'
</script>


<template>
    <div>
        <!-- <NavBar/> -->
    </div>
    <div>
        <h1>This is where dreams come true</h1>
    <router-link to="/blog">Go To Blog</router-link> <br>
    <router-link to="/Register">Go To Register</router-link> <br>
    <router-link to="/RegLecture">Go To RegLecture</router-link>
    </div>
    
</template>
<style scoped>
</style>
