<script setup>
import Navigation from './components/Navigation.vue'
</script>

<template>
  <Navigation />
  <router-view></router-view>
</template>

<style scoped>

</style>
