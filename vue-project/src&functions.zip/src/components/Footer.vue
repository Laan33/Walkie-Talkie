<template>
<ul>
  <li><a href="/about">About</a></li>
  <li>Blog</li>
  <li>Google</li>
</ul>
</template>

<style scoped>

</style>