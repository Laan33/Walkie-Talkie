<script setup>
import HelloWorld from '../components/HelloWorld.vue'
</script>

<template>
  <HelloWorld msg="You did it!" />

</template>

<style scoped>

</style>